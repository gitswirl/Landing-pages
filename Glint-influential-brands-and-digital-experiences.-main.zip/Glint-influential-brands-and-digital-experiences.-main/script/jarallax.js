$('.jarallax').jarallax({
    speed: 0.4,
});